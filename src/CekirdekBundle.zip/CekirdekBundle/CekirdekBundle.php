<?php

namespace CekirdekBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CekirdekBundle extends Bundle
{
}
